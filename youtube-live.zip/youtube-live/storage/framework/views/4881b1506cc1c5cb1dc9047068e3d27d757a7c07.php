<?php $__env->startSection('content'); ?>
<br>
<div class="container">
    <div class="row">
        <div class="col">
            <h3> All Broadcasts </h3>
        </div>
    </div>
</div>
<br>
<div class="container">
    <?php $__currentLoopData = $broadcasts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $broadcast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col">
                <a href="live-stream?id=<?php echo e($broadcast['id']); ?>&liveChatId=<?php echo e($broadcast['snippet']['liveChatId']); ?>"> <?php echo e($broadcast['snippet']['title']); ?> </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>